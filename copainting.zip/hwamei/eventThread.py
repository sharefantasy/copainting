__author__ = 'FanTasY'

import threading
import redis
# import models


class redisEventThread(threading.Thread):
    pool = redis.ConnectionPool(host="localhost", port=6379, db=0)

    def __init__(self):
        super(redisEventThread, self).__init__()
        self.sub = redis.StrictRedis(connection_pool=self.pool).pubsub()
        self.sub.subscribe('chat')

    def run(self):
        while True:
            for i in self.sub.listen():
                print i

if __name__ == "__main__":
    # r = redisEventThread()
    ps = redis.StrictRedis()
    while True:
        try:
            ps.publish("chat", "aa")
        except KeyboardInterrupt:
            break
