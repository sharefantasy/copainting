__author__ = 'fantasy'


class Palette():
    def __init__(self):
        self.colors = []
        self.colors.extend([
            ['red', [255, 0, 0, 255]],
            ['orange', [255, 157, 0, 255]],
            ['yellow', [255, 248, 10, 255]],
            ['green', [0, 255, 0, 255]],
            ['cyan', [94, 166, 0, 255]],
            ['blue', [0, 0, 255, 255]],
            ['purple', [97, 30, 73, 255]],
        ])
