
__author__ = 'fantasy'

from bootstrap.forms import *
from django.forms.fields import PasswordInput, CharField
from django import forms


class LoginForm(BootstrapForm):
    class Meta:
        layout = (Fieldset("Sign In", "username", "password",),)
    username = CharField(widget=forms.TextInput({'required': 'required'}), label="User Name")
    password = CharField(widget=PasswordInput({'required': 'required'}), label="Password")
